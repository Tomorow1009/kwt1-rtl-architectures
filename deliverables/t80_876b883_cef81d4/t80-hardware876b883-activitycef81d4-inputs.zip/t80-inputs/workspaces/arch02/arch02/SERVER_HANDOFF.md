# 架构二服务器验证交接

更新时间：2026-11-08。本文件随服务器工作更新；未列为通过的项目不得视为验收完成。

## 工程与数据

- 本地源码：`D:\IC_compeyition\Fast_coding\arch02`；依赖上一级 `rtl/dot64.sv`、`rtl/requantize.sv` 和 `vectors`。
- 本地模型资料：`D:\IC_compeyition\Fast_coding\KWT1`。
- FileZilla 远程站点上传目录：`/IC`，对应服务器 `/storage2/2026contest/server4/s4_21usr/Desktop/IC`。注意用户名为 `s4_21usr`，目录为大写 `IC`。
- SRAM 库：`/storage1/admin_public_dir/SRAM_Lib_2025`。
- 工艺资料：`/storage1/admin_public_dir/SMIC40_2025`。
- 服务器验证使用独立 `arch02_server_r01/r02/r03` 目录，保留每次失败和修复证据，不覆盖原工程。

计算为第一线性层 `X[99,64] × W[64,256] + b[256]`，每层 25344 个输出，12 层共 304128 个。各层输入来自独立捕获，不是卷积、端到端推理或分类正确率测试。

## 硬件组织

8 路输出通道并行。X 使用 2 个 RAMSP4096X16，当前 8 列 W 使用 8 个 RAMSP128X16，总配置容量 18 KiB。单缓冲，加载与计算不重叠。数值格式和具体接口见 `README.md`。

输入/权重 signed16、12 位小数；偏置 signed40、24 位小数；累加器 40 位，加偏置总和 41 位。半值远离零舍入，signed16 饱和输出。真实数据 shift=12。

一层加载 23488 个 16 位字：6336 个 X，然后每组 512 个权重及 24 个偏置字，共 32 组。输出顺序 group→row→lane，写回地址 `row*256+group*8+lane`。不能按输出出现顺序直接重建行优先矩阵。

## 已核实的厂商接口

直接编译库内 `RAMSP128X16/verilog/RAMSP128X16.v` 与 `RAMSP4096X16/verilog/RAMSP4096X16.v`，实例化底层同名模块。CEN、GWEN、逐位 WEN 低有效；EMA=2、EMAW=0、RET1N=1，正沿同步访问。RET1N 不是阵列复位。

配置和外部模型清单分别为服务器版本目录中的 `vendor_config.json`、`vendor.f`，不允许替代模型回退。模型和受测源码 SHA-256 记录在每轮 `summary.json`。

## 本次发现及修复

1. 默认厂商模型 Q 在上升沿后 1 ns 更新，原宏单测同一时刻采样产生调度竞争。`tb/tb_sram_adapter.sv` 保留 +1 ns 有效检查，将数据比较移至 +4 ns、下降沿之前；复位期间取消数据检查。
2. 修复后的本地 behavioral/pin_mock × Icarus/XSim 宏单测全部通过，每组包含两种容量及两种延迟共 4 个用例。日志：`sim/adapter_sampling_20261108_000502`。
3. 服务器 r02 默认厂商时序分支宏单测通过，但完整矩阵在控制/地址零延迟切换时触发 0.5 ns hold 检查。失败证据保留于 `arch02_server_r02/server_runs/20261108_000846_558001`。
4. r03 显式选择相同厂商文件内的 `ARM_UD_MODEL` 功能分支，验证 RTL 数值及协议。没有修改核心 MAC/转换逻辑，也没有用自编 pin_mock 替代实际厂商模型。功能分支通过不代表默认时序分支或物理时序通过。

## 服务器运行方法

服务器 Python 3.6.8 无 NumPy；上传包包含此前从完整 NPZ 校验导出的紧凑 HEX。服务器使用 Python 整数重新计算全部 total/result/saturated；不在服务器重新执行模型推理。

在版本目录、已初始化 VCS 环境中运行：

```sh
python3 vcs_run.py --mode all --config vendor_config.json --filelist vendor.f --vendor-mode functional
```

`--vendor-mode timing` 为默认厂商时序分支；不要把两种模式的结论混用。每轮独立保存到 `server_runs/<时间戳>`，成功必须检查最终 `VCS_VENDOR_PASS` 及 `summary.json` 的 passed 状态。

完整回归包括 12 层真实矩阵、极值/舍入定向矩阵、2 拍接口、9 个复位探针、1103×8 数值检查和 6 个预期失败测试。实际输出 CSV 含矩阵位置、total、result、saturated，Python 按坐标重建并比较；定向任务不能重复计入 304128 个真实输出覆盖。

`/IC/a0.sh` 为 r03 一次性创建及运行脚本，目标存在时拒绝覆盖；不要重复执行以覆盖历史运行。通过后它继续做库盘点和 DC 环境发现，**不等同于已完成综合**。

## 当前验收边界

r03 运行目录：`arch02_server_r03/server_runs/20261108_002041_339634`。已通过 VNC 观察到最终 `VCS_VENDOR_PASS mode=all model=functional real_outputs=304128`，12 层全部真实输出、极值/舍入、数值边界及六项预期失败检查通过。脚本在最终 PASS 前完成矩阵重建比对及源码哈希复核。

最终独立审计目录：`arch02_server_r03/audits/20261108_005913`。观察到 `FINAL_INTEGER_AND_CAPTURE_RECHECK 304128`、`FINAL_MACROS 128=8 4096=2 LATCHES=0 CHECK_DESIGN=1` 及 `FINAL_AUDIT_PASS`。审计重新读 HEX 并重算全部答案、按坐标重读实际输出 CSV，检查每层无遗漏/重复，复核 VCS 使用的源码与厂商模型哈希，并重新打开最终 DDC 检查链接及锁存器。

最终设计检查仍报告 LINT-2/8/28/32/33 告警，时序检查有 TIM-216（复位输入未指定时钟相对延迟）；不能将 `CHECK_DESIGN=1` 理解为完全没有告警。已用 `/IC/h.sh` 核对样例：LINT-2 为优化后无负载的算术高位网络；LINT-8 为 DesignWare 加法器未使用的高位输入；LINT-28 为内部运算单元未连接的 TC/CI/CO 端口；LINT-32 为有意连接的符号模式与进位常量；LINT-33 为符号扩展同一网络连接多个位。没有从这些样例发现新的功能接线缺陷，保留原始告警便于集成审阅。TIM-134 指理想时钟高扇出，VO-4 指输出网表含 assign/tran；复位时序与实际时钟树属于已声明的集成边界。

DC 库盘点已完成，目录为 `arch02_server_r03/dc_runs/inventory_20261108_002156`。默认 DC 配置仅含 `your_library.db` 占位项，不能直接用于本工程。已选取归档 `SMIC40_2025/S40.tar.gz` 中 RVT SS、0.99 V、125°C 的 `scc40nll_vhsc40_rvt_ss_v0p99_125c_basic.db`，与两种 SRAM 的 SS、0.99 V、125°C 库匹配。SRAM Liberty 声明时间单位 1 ns、电容单位 1 pF；128/4096 宏 cell area 分别为 2677.051 和 27517.3168，面积已与后述 SRAM LEF 尺寸核对。

`/IC/d.sh` 已完成首轮综合，独立目录为 `arch02_server_r03/dc_runs/synth_20261108_003637`，终端出现 `SYNTHESIS_REPORTS_READY`。脚本生成 `inputs.json`、`synth.tcl`、网表/DDC/SDC 和面积、setup/hold、约束及设计检查报告。周期 6.667 ns，时钟不确定度 0.1 ns；外部输入/输出最大延迟暂定 1 ns、最小 0 ns，输入转换 0.1 ns，输出负载 0.01 pF。这些是独立模块综合假设，后续须以 SoC 接口预算替换。复位数据路径排除，释放同步由集成负责，不能据此声称恢复/移除时间验收通过。

首轮 QoR：setup 违例数 0，汇总关键裕量显示 0.00 ns（精确值尚待详细报告）；hold 违例数 189，最差约 -0.50 ns，总负 hold 裕量约 -81.25 ns。总 cell area 显示 127583.370120，其中 macro/black-box area 76451.041016；设计规则 max transition/max capacitance 违例数均为 0。**本轮时序未通过，不能因 setup 无违例而忽略 hold。**

已通过服务器 LEF 核对：RAMSP128X16 为 55.9×47.89 μm，RAMSP4096X16 为 135.58×202.96 μm，与 Liberty cell area 一致。两大八小宏合计约 0.076451 mm²。总综合面积约 0.127583 mm²，仍为逻辑综合估计，未包含物理实现空白、时钟树及后续 SoC 接口增量。QoR 的 Macro Count 字段显示 0，而 Macro/Black Box Area 非零；必须根据引用名逐实例复核 2+8，不能单独拿该字段判断 SRAM 缺失。

`server_delivery/f.sh` 已读取首轮 DDC，在相同工艺角及外部预算下执行 `set_fix_hold` 和增量综合，完成目录为 `arch02_server_r03/dc_runs/hold_20261108_005224`，首轮结果未覆盖。终端出现 `HOLD_REPORTS_READY`。

修复后 setup/hold 违例均为 0，最差 setup 裕量 **+0.000641823 ns**，最差 hold 裕量 **+0.00111431 ns**；设计规则 max transition/max capacitance 违例仍为 0。总综合 cell area **127956.514920 μm²（约 0.127957 mm²）**，较首轮增加约 373.145 μm²。按引用名逐实例确认 RAMSP128X16=8、RAMSP4096X16=2；SRAM 没有被行为数组或逻辑门替换。

setup 最差路径为 X bank 0 SRAM 时钟到 lane 7 accumulator[31]；hold 最差路径为 state_reg[1] 到 X bank 0 SRAM A[8]。这些正裕量极小，只证明该单一 SS 角、理想时钟和暂定 IO 预算下的综合检查通过，不是全角或布线后裕量保证。默认厂商 RTL 时序分支的原始 hold 报错仍保留，不能将增量综合结果表述为已重新通过那一轮 RTL 仿真。

本次 6.667 ns 综合约束下 setup/hold 检查通过，面积估计小于 2.25 mm²；尚未完成真实系统集成、多角布局布线时序或功耗验收。最终独立审计脚本为 `/IC/g.sh`，会重算 304128 个整数答案、重新比对实际输出 CSV、复核源码/厂商模型哈希，并读取最终 DDC 检查锁存器及设计链接。

后续 SoC 总线、E203 调度、真实写响应、官方评测集 NRMSE 与分类准确率均未由本次独立矩阵验证覆盖。不得将 304128 个整数结果一致描述为“全部语音识别成功”。


## 文件与复现入口速查

服务器当前可交接版本为 `/storage2/2026contest/server4/s4_21usr/Desktop/IC/arch02_server_r03`，不是原始 `/IC/arch02` 副本。运行时需要根目录 `rtl` 与 `arch02/rtl` 两部分，不要只复制子目录后漏掉共享 MAC。

- 功能回归：在 r03 目录运行前述 `python3 vcs_run.py ... --vendor-mode functional`；所有实际输出 CSV 和逐项矩阵在 `server_runs/20261108_002041_339634`。
- 首次综合：在 `/IC` 执行 `sh d.sh`，生成独立新目录；实际读取的是 r03 固定源码快照和指定慢角库。
- 既有基线的 hold 修复：`sh f.sh` 固定读取本报告首轮 DDC；切换基线时须同时修改该引用，不能误用旧 DDC。
- 独立复核：`sh g.sh` 固定审计本报告所列功能运行和最终 DDC；检查新版时须同步更换路径。
- 波形：功能回归的 `arch02.vcd` 来自 rounding 的两拍接口、复位及连续任务作业，真实 12 层不启用全量波形。可在服务器 Verdi 的波形窗口通过 Open 导入该 VCD；它不是带 SDF 的门级时序波形。
- 网表/约束：`dc_runs/hold_20261108_005224/arch02_mapped.v`、`arch02_mapped.ddc`、`arch02.sdc`；同目录保存最终报告。

本地改动是宏单测采样时刻与 `scripts/server_vcs.py` 的显式厂商功能分支选择，以及服务器运行/检查脚本与文档。核心 MAC、数值转换、架构二调度 RTL SHA-256 未改变；原行为模型和 pin_mock 的历史全量证据保留，本次额外重跑的本机宏单测见 `sim/adapter_sampling_20261108_000502/summary.json`。未上传 GitHub，未下载厂商库到本机。
